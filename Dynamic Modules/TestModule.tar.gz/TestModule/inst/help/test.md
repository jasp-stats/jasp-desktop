TITEL!!!
==========================

The independent samples t-test allows you to test the null hypothesis that the population means of two independent groups are equal.

Hmm
